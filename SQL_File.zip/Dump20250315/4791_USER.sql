-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (x86_64)
--
-- Host: 127.0.0.1    Database: 4791
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `USER`
--

DROP TABLE IF EXISTS `USER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `membership_id` int DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_phone_number` varchar(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `registeration_date` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `membership_id` (`membership_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`membership_id`) REFERENCES `MEMBERSHIP` (`membership_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER`
--

LOCK TABLES `USER` WRITE;
/*!40000 ALTER TABLE `USER` DISABLE KEYS */;
INSERT INTO `USER` VALUES (1,1,'Alice Smith','alice@example.com','1234567890','1990-05-15','2025-03-08 22:20:56'),(2,2,'Bob Johnson','bob@example.com','1231231234','1985-08-20','2025-03-08 22:20:56'),(3,3,'Charlie Brown','charlie@example.com','2342342345','1992-03-10','2025-03-08 22:20:56'),(4,4,'Diana Prince','diana@example.com','3453453456','1988-12-25','2025-03-08 22:20:56'),(5,5,'Evan Davis','evan@example.com','4564564567','1995-07-30','2025-03-08 22:20:56'),(6,6,'Fiona Green','fiona@example.com','5675675678','1991-09-15','2025-03-08 22:20:56'),(7,7,'George Hall','george@example.com','6786786789','1980-04-22','2025-03-08 22:20:56'),(8,8,'Hannah Lee','hannah@example.com','7897897890','1993-11-05','2025-03-08 22:20:56'),(9,9,'Ian King','ian@example.com','8908908901','1987-06-18','2025-03-08 22:20:56'),(10,10,'Julia Moore','julia@example.com','9019019012','1996-02-28','2025-03-08 22:20:56'),(11,NULL,'user1@example.com','user1@example.com','98987777','2025-03-08','2025-03-08 23:21:41'),(12,1,'test','test1@gmail.com','77779999','2025-03-08','2025-03-08 23:22:58'),(13,1,'test','test','123232','2025-03-08','2025-03-08 23:32:04'),(14,6,'Alice Johnson','alice@example.com','1234567890','1990-05-15','2024-01-01 00:00:00'),(15,7,'Bob Smith','bob@example.com','9876543210','1995-08-20','2024-02-10 00:00:00'),(16,8,'Charlie Brown','charlie@example.com','4567891230','1988-11-25','2024-03-15 00:00:00'),(17,9,'David Wilson','david@example.com','3216549870','2000-07-30','2024-04-05 00:00:00'),(18,10,'Emma Davis','emma@example.com','1597534680','1992-02-17','2024-05-20 00:00:00'),(19,6,'Frank Thomas','frank@example.com','1472583690','1993-09-12','2024-02-05 00:00:00'),(20,7,'Grace Miller','grace@example.com','2583691470','1998-06-22','2024-06-10 00:00:00'),(21,8,'Henry White','henry@example.com','3691472580','1985-04-08','2024-07-25 00:00:00'),(22,9,'Isabella Scott','isabella@example.com','9873216540','1996-12-10','2024-08-15 00:00:00'),(23,10,'Jack Robinson','jack@example.com','7418529630','2001-03-29','2024-09-05 00:00:00'),(24,6,'Liam Carter','liam@example.com','8529637410','1997-05-30','2024-10-20 00:00:00'),(25,7,'Mia Collins','mia@example.com','9637418520','1994-07-21','2024-11-15 00:00:00'),(26,8,'Noah Martin','noah@example.com','3216549870','1989-10-11','2024-12-01 00:00:00'),(27,9,'Olivia Baker','olivia@example.com','6549873210','1991-08-25','2025-01-05 00:00:00'),(28,10,'Peter Adams','peter@example.com','7894561230','1999-11-17','2025-02-10 00:00:00'),(29,6,'Quinn Wright','quinn@example.com','9517538520','1990-04-02','2025-03-01 00:00:00'),(30,7,'Rachel Young','rachel@example.com','3579518520','1987-02-14','2025-04-12 00:00:00'),(31,8,'Samuel Clark','samuel@example.com','6541237890','1993-06-19','2025-05-15 00:00:00'),(32,9,'Taylor Harris','taylor@example.com','8521473690','2002-01-09','2025-06-30 00:00:00'),(33,10,'Ursula Evans','ursula@example.com','7413698520','1995-12-23','2025-07-07 00:00:00');
/*!40000 ALTER TABLE `USER` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-15 16:53:46
