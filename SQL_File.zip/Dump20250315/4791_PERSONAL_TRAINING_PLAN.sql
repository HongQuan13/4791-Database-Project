-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (x86_64)
--
-- Host: 127.0.0.1    Database: 4791
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PERSONAL_TRAINING_PLAN`
--

DROP TABLE IF EXISTS `PERSONAL_TRAINING_PLAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERSONAL_TRAINING_PLAN` (
  `plan_id` int NOT NULL AUTO_INCREMENT,
  `trainer_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `plan_details` text,
  `plan_start_date` date DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `progress_status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`plan_id`),
  KEY `trainer_id` (`trainer_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `personal_training_plan_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `TRAINER` (`trainer_id`),
  CONSTRAINT `personal_training_plan_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `USER` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERSONAL_TRAINING_PLAN`
--

LOCK TABLES `PERSONAL_TRAINING_PLAN` WRITE;
/*!40000 ALTER TABLE `PERSONAL_TRAINING_PLAN` DISABLE KEYS */;
INSERT INTO `PERSONAL_TRAINING_PLAN` VALUES (1,1,1,'Plan A: Strength and conditioning','2024-01-03',30,'In Progress'),(2,2,2,'Plan B: Yoga and flexibility','2024-01-04',45,'Completed'),(3,3,3,'Plan C: Boxing training','2024-01-05',60,'In Progress'),(4,4,4,'Plan D: Tennis conditioning','2024-01-06',30,'In Progress'),(5,5,5,'Plan E: Martial arts basics','2024-01-07',50,'Completed'),(6,6,6,'Plan F: Stunt training fundamentals','2024-01-08',40,'In Progress'),(7,7,7,'Plan G: Gymnastics regimen','2024-01-09',35,'In Progress'),(8,8,8,'Plan H: Sprinting techniques','2024-01-10',45,'Completed'),(9,9,9,'Plan I: Swimming drills','2024-01-11',55,'In Progress'),(10,10,10,'Plan J: Tennis skills','2024-01-12',30,'In Progress'),(11,1,1,'test','2025-03-08',1,'In Progress');
/*!40000 ALTER TABLE `PERSONAL_TRAINING_PLAN` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-15 16:53:46
