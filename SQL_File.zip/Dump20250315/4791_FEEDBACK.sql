-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (x86_64)
--
-- Host: 127.0.0.1    Database: 4791
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `FEEDBACK`
--

DROP TABLE IF EXISTS `FEEDBACK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FEEDBACK` (
  `feedback_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `trainer_id` int DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `comments` text,
  `feedback_time` datetime DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  KEY `trainer_id` (`trainer_id`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `USER` (`user_id`),
  CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `TRAINER` (`trainer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEEDBACK`
--

LOCK TABLES `FEEDBACK` WRITE;
/*!40000 ALTER TABLE `FEEDBACK` DISABLE KEYS */;
INSERT INTO `FEEDBACK` VALUES (1,1,1,4.50,'Great session!','2024-01-05 11:00:00'),(2,2,2,4.00,'Very helpful.','2024-01-06 12:10:00'),(3,3,3,3.50,'Good, but could improve.','2024-01-07 10:15:00'),(4,4,4,5.00,'Excellent!','2024-01-08 13:15:00'),(5,5,5,4.20,'Well explained techniques.','2024-01-09 09:30:00'),(6,6,6,3.80,'Satisfactory session.','2024-01-10 15:10:00'),(7,7,7,4.70,'Very motivating!','2024-01-11 11:45:00'),(8,8,8,4.10,'Good pace and instructions.','2024-01-12 16:05:00'),(9,9,9,3.90,'Could be better.','2024-01-13 17:20:00'),(10,10,10,4.60,'Really enjoyed it.','2024-01-14 10:40:00'),(11,1,1,2.00,'test ','2025-03-08 23:32:52'),(12,1,1,4.50,'Great strength training session!','2024-06-01 10:00:00'),(13,2,2,4.80,'Loved the yoga session.','2024-06-02 10:30:00'),(14,3,3,4.20,'Intense cardio workout!','2024-06-03 09:30:00'),(15,4,1,5.00,'Trainer John was amazing.','2024-06-04 21:00:00'),(16,5,2,4.00,'Good session, could be longer.','2024-06-05 08:00:00'),(17,6,3,4.60,'Very motivational coach!','2024-06-06 10:00:00'),(18,7,1,4.90,'Excellent coaching!','2024-06-07 09:00:00'),(19,8,2,4.40,'Nice flexibility session.','2024-06-08 07:30:00'),(20,9,3,4.70,'Best HIIT session ever!','2024-06-09 10:30:00'),(21,10,1,4.10,'Trainer John is knowledgeable.','2024-06-10 11:00:00'),(22,11,2,4.30,'Yoga helped my back pain.','2024-06-11 08:45:00'),(23,12,3,4.50,'Great endurance training!','2024-06-12 12:00:00'),(24,13,1,4.20,'Fun workout.','2024-06-13 14:30:00'),(25,14,2,4.00,'Relaxing yoga session.','2024-06-14 16:45:00'),(26,15,3,4.80,'Best HIIT class I attended!','2024-06-15 18:00:00'),(27,16,1,4.90,'John is the best coach!','2024-06-16 07:45:00'),(28,17,2,4.30,'Great flexibility tips.','2024-06-17 09:15:00'),(29,18,3,4.50,'Helped with weight loss.','2024-06-18 10:00:00'),(30,19,1,4.60,'Pushed me to my limits!','2024-06-19 11:30:00'),(31,20,2,4.70,'Enjoyed every session!','2024-06-20 12:15:00');
/*!40000 ALTER TABLE `FEEDBACK` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-15 16:53:46
