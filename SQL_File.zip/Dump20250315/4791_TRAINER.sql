-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (x86_64)
--
-- Host: 127.0.0.1    Database: 4791
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TRAINER`
--

DROP TABLE IF EXISTS `TRAINER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRAINER` (
  `trainer_id` int NOT NULL AUTO_INCREMENT,
  `trainer_name` varchar(100) DEFAULT NULL,
  `trainer_specialization` varchar(100) DEFAULT NULL,
  `trainer_phone_number` varchar(20) DEFAULT NULL,
  `trainer_email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`trainer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRAINER`
--

LOCK TABLES `TRAINER` WRITE;
/*!40000 ALTER TABLE `TRAINER` DISABLE KEYS */;
INSERT INTO `TRAINER` VALUES (1,'John Doe','Strength Training','1112223333','johndoe@example.com'),(2,'Jane Roe','Yoga & Flexibility','2223334444','janeroe@example.com'),(3,'Mike Tyson','Boxing','3334445555','mike@example.com'),(4,'Serena Williams','Tennis Conditioning','4445556666','serena@example.com'),(5,'Bruce Lee','Martial Arts','5556667777','bruce@example.com'),(6,'Jackie Chan','Stunt Training','6667778888','jackie@example.com'),(7,'Simone Biles','Gymnastics','7778889999','simone@example.com'),(8,'Usain Bolt','Sprinting','8889990000','usain@example.com'),(9,'Michael Phelps','Swimming','9990001111','michael@example.com'),(10,'Roger Federer','Tennis','0001112222','roger@example.com'),(11,'John Miller','Strength Training','1231231234','john.trainer@example.com'),(12,'Sarah Lee','Yoga & Flexibility','4564564567','sarah.trainer@example.com'),(13,'Michael Davis','Cardio & HIIT','7897897890','michael.trainer@example.com'),(14,'Anna Smith','Weight Loss Coaching','1122334455','anna.trainer@example.com'),(15,'Robert Brown','CrossFit & Endurance','2233445566','robert.trainer@example.com'),(16,'Emma Wilson','Pilates & Rehab','3344556677','emma.trainer@example.com'),(17,'Daniel Harris','Athletic Performance','4455667788','daniel.trainer@example.com'),(18,'Sophia Clark','Dance & Aerobics','5566778899','sophia.trainer@example.com'),(19,'James White','Powerlifting','6677889900','james.trainer@example.com'),(20,'Lily Evans','Senior Fitness','7788990011','lily.trainer@example.com'),(21,'Henry Cooper','Marathon Training','8899001122','henry.trainer@example.com'),(22,'Olivia Scott','Bodybuilding','9900112233','olivia.trainer@example.com'),(23,'Lucas Walker','Swimming & Aquatic Training','1010101010','lucas.trainer@example.com'),(24,'Ella Roberts','Gymnastics & Mobility','1111111111','ella.trainer@example.com'),(25,'William Davis','Strength & Conditioning','2222222222','william.trainer@example.com'),(26,'Ava Moore','Stretching & Recovery','3333333333','ava.trainer@example.com'),(27,'Ethan Hill','HIIT & Bootcamp','4444444444','ethan.trainer@example.com'),(28,'Mia Lewis','Group Fitness','5555555555','mia.trainer@example.com'),(29,'Noah Allen','Rehabilitation & Therapy','6666666666','noah.trainer@example.com'),(30,'Charlotte King','Personalized Coaching','7777777777','charlotte.trainer@example.com');
/*!40000 ALTER TABLE `TRAINER` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-15 16:53:45
